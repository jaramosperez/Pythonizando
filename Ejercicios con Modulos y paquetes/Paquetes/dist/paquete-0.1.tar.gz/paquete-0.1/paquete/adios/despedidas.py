# Este es un módulo con funciones que se despide.
def despedirse():
    print("Adios, me estoy despidiendo desde la función despedirse del módulo despedidas")


class Despedida():
    def __init__(self):
        print("Adios, me estoy despidiendo desde el init de la clase Desdepedida")
